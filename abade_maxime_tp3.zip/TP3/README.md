# TP3 SIGNAUX

## Exercice 1

### COMPILATION & EXECUTION

``` gcc ex1.c -o exec && ./exec ```

## Exercice 2

### COMPILATION & EXECUTION

``` gcc ex2.c -o exec && ./exec ```

## Exercice 3

### COMPILATION & EXECUTION

``` gcc ex3.c -o exec && ./exec ```

## Exercice 4

### COMPILATION & EXECUTION

``` gcc ex4.c -o exec && ./exec ```

### NB 
<p>Ici, vous pouvez voir que le processus tourne sans fin tant que les processus sont vivants. Pensez à utiliser la commande ``` fkill <PID> ``` , à remplacer avec le PID / PPID du processus à kill pour mettre fin au programme.</p>
<p>Tuer le processus père tuera automatiquement le fils, pensez-y!</p>


